
const { MessageEmbed } = require("discord.js");
const api = require("imageapi.js");

module.exports = {
    name: "meme",
    description: "Un meme bacano papá",
    usage: "meme",
    permissions: {
      channel: ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"],
      member: [],
    },
    aliases: ["shitpost",],
    run: async(client, message) => {
        const subreddits = ['Shitposting_esp'];
        const subreddit = subreddits[Math.floor(Math.random() * (subreddits.length))];
        const meme = await api.advanced(subreddit);

        return message.channel.send(new MessageEmbed()
      /*  .setTitle(`r/${subreddit}`)
        .setURL(`https://reddit.com/r/${subreddit}`)
        .setDescription(`${meme.upvoteRatio}% De gente que le gustó esto`)*/
        .setImage(meme.img)
        )

    }
}